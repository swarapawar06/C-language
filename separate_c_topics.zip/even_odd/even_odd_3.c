#include <stdio.h>
void check(int n) {
    if(n%2) printf("Odd\n"); else printf("Even\n");
}
int main() {
    check(11);
    return 0;
}