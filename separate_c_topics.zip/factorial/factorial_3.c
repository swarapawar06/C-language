#include <stdio.h>
int main() {
    int n = 4, fact = 1;
    while(n > 0) fact *= n--;
    printf("Factorial = %d\n", fact);
    return 0;
}