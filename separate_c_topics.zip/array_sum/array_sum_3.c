#include <stdio.h>
int sum_array(int a[], int n) {
    int sum = 0;
    for(int i = 0; i < n; i++) sum += a[i];
    return sum;
}
int main() {
    int arr[] = {10, 20, 30};
    printf("Sum = %d\n", sum_array(arr, 3));
    return 0;
}