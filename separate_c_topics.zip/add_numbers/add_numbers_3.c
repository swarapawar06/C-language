#include <stdio.h>
int sum(int a, int b) { return a + b; }
int main() {
    printf("Sum = %d\n", sum(3, 7));
    return 0;
}